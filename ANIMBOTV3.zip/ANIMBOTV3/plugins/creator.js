let handler = function (m) {
  // this.sendContact(m.chat, '6281216374929', 'Anim', m)
  this.sendContact(m.chat, '6281216374929', 'Admin BOT', m)
}
handler.help = ['owner', 'creator']
handler.tags = ['info']

handler.command = /^(owner|creator)$/i

module.exports = handler
